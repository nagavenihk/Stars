package org.AssistedPractice;


public class pubaccessspecifier {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}
