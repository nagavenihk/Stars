package org.AssistedPractice;

public class proaccessspecifier {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 


}
