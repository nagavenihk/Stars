package org.AssistedPractice1;
import org.AssistedPractice.*;

public class pubaccessspecifier1 extends pubaccessspecifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pubaccessspecifier1 obj = new pubaccessspecifier1(); 
        obj.display();  


	}

}
