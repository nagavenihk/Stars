package org.AssistedPractice1;
import org.AssistedPractice.*;

public class proaccessspecifier1 extends proaccessspecifier {
	public static void main(String[] args) {
		proaccessspecifier1 obj = new proaccessspecifier1 ();   
	       obj.display();  
	}

}
